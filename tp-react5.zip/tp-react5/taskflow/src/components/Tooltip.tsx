import { useState, useLayoutEffect, useEffect, useRef } from 'react';

export default function Tooltip() {
  const [position, setPosition] = useState({ top: 0, left: 0 });
  const [useLayout, setUseLayout] = useState(false);
  const buttonRef = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (useLayout) return;
    if (buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect();
      setPosition({ top: rect.bottom + 8, left: rect.left });
    }
  }, [useLayout]);

  useLayoutEffect(() => {
    if (!useLayout) return;
    if (buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect();
      setPosition({ top: rect.bottom + 8, left: rect.left });
    }
  }, [useLayout]);

  return (
    <div style={{ padding: '1rem 0 2rem 0' }}>
      <button
        onClick={() => {
          setPosition({ top: 0, left: 0 });
          setUseLayout((prev) => !prev);
        }}
        style={{
          background: '#1B8C3E',
          color: 'white',
          border: 'none',
          padding: '10px 16px',
          borderRadius: '8px',
          cursor: 'pointer',
          fontWeight: 600,
          marginBottom: '16px',
        }}
      >
        Basculer : {useLayout ? 'useLayoutEffect' : 'useEffect'}
      </button>

      <br />

      <button
        ref={buttonRef}
        style={{
          background: 'white',
          color: '#1B8C3E',
          border: '1px solid #1B8C3E',
          padding: '10px 16px',
          borderRadius: '8px',
          cursor: 'pointer',
          fontWeight: 600,
        }}
      >
        Survolez-moi
      </button>

      <div
        style={{
          position: 'fixed',
          top: position.top,
          left: position.left,
          background: position.top === 0 ? 'red' : '#333',
          color: 'white',
          padding: '0.5rem 1rem',
          borderRadius: '6px',
          transition: 'none',
          zIndex: 9999,
        }}
      >
        {position.top === 0 ? 'FLASH (0,0)' : 'Info-bulle positionnée !'}
      </div>
    </div>
  );
}