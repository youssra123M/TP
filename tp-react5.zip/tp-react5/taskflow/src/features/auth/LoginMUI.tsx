import { useState } from 'react';
import { Box, Card, CardContent, TextField, Button, Typography, Alert } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from './AuthContext';
import api from '../../api/axios';

export default function LoginMUI() {
  const { state, dispatch } = useAuth();
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    console.log('handleSubmit lancé');

    dispatch({ type: 'LOGIN_START' });

    try {
      const { data: users } = await api.get(`/users?email=${email}`);
      console.log('users trouvés :', users);

      if (!users || users.length === 0) {
        dispatch({
          type: 'LOGIN_FAILURE',
          payload: 'Email ou mot de passe incorrect',
        });
        return;
      }

      const user = users[0];

      if (user.password !== password) {
        dispatch({
          type: 'LOGIN_FAILURE',
          payload: 'Email ou mot de passe incorrect',
        });
        return;
      }

      const { password: _, ...safeUser } = user;

      dispatch({
        type: 'LOGIN_SUCCESS',
        payload: safeUser,
      });

      console.log('connexion réussie');
      navigate('/'); // ou '/dashboard' selon ton projet
    } catch (error) {
      console.error('Erreur login :', error);
      dispatch({
        type: 'LOGIN_FAILURE',
        payload: 'Erreur serveur',
      });
    }
  }

  return (
    <Box
      sx={{
        minHeight: '100vh',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        bgcolor: '#f4f4f4',
      }}
    >
      <Card sx={{ width: 460, p: 2 }}>
        <CardContent>
          <Typography variant="h3" align="center" color="success.main" fontWeight="bold" mb={3}>
            TaskFlow
          </Typography>

          <Typography variant="h6" align="center" mb={3}>
            Connectez-vous pour continuer
          </Typography>

          {state.error && <Alert severity="error" sx={{ mb: 2 }}>{state.error}</Alert>}

          <form onSubmit={handleSubmit}>
            <TextField
              fullWidth
              label="Email"
              margin="normal"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />

            <TextField
              fullWidth
              label="Mot de passe"
              type="password"
              margin="normal"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />

            <Button
              type="submit"
              fullWidth
              variant="contained"
              color="success"
              sx={{ mt: 3, py: 1.5 }}
            >
              SE CONNECTER
            </Button>
          </form>
        </CardContent>
      </Card>
    </Box>
  );
}