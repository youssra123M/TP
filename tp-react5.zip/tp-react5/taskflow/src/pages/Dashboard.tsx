import { useState, useEffect, useCallback } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import Header from '../components/Header';
import Sidebar from '../components/Sidebar';
import MainContent from '../components/MainContent';
import ProjectForm from '../components/ProjectForm';
import useProjects, { type Project } from '../hooks/useProjects';
import styles from './Dashboard.module.css';
import type { RootState, AppDispatch } from '../store';
import { logout } from '../features/auth/authSlice';
import { setAuthToken } from '../api/axios';

export default function Dashboard() {
  const dispatch = useDispatch<AppDispatch>();
  const { user, token } = useSelector((state: RootState) => state.auth);

  const {
    projects,
    columns,
    loading,
    error,
    addProject,
    renameProject,
    deleteProject,
  } = useProjects();

  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    setAuthToken(token);
  }, [token]);

  const handleRename = useCallback(
    (project: Project) => {
      renameProject(project);
    },
    [renameProject]
  );

  const handleDelete = useCallback(
    (id: string) => {
      deleteProject(id);
    },
    [deleteProject]
  );

  if (loading) {
    return <div className={styles.loading}>Chargement...</div>;
  }

  return (
    <div className={styles.layout}>
      <Header
        title="TaskFlow"
        onMenuClick={() => setSidebarOpen((prev) => !prev)}
        userName={user?.name}
        onLogout={() => dispatch(logout())}
      />

      <div className={styles.body}>
        <Sidebar
          projects={projects}
          isOpen={sidebarOpen}
          onRename={handleRename}
          onDelete={handleDelete}
        />

        <div className={styles.content}>
          <div className={styles.toolbar}>
            {!showForm ? (
              <button className={styles.addBtn} onClick={() => setShowForm(true)}>
                + Nouveau projet
              </button>
            ) : (
              <ProjectForm
                submitLabel="Créer"
                onSubmit={async (name, color) => {
                  await addProject(name, color);
                  setShowForm(false);
                }}
                onCancel={() => setShowForm(false)}
              />
            )}
          </div>

          {error && <div className={styles.error}>{error}</div>}

          <MainContent columns={columns} />
        </div>
      </div>
    </div>
  );
}